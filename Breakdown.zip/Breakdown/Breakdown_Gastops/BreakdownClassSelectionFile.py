
"""
Breakdown Class Selection File

Created on Mon Jun 11 15:24:11 2018

@author: Jeremy Barrette P928247
"""

import sys
import pandas as pd

import BreakdownClassSelectionFile

def BuildClasses():

    #To build the constants needed for the class selection and load values
    constBuild = pd.read_csv('Data\ConstantBuild.csv', low_memory = False)
    corrValues = pd.read_csv('Data\Corrected_Values.csv', low_memory = False)
    classSelection = pd.read_csv('Data\ClassSelection.csv', low_memory = False)

    modifierValues = []
    constHeader = list(constBuild)
    for ind, dataRow in corrValues.iterrows():
        valueRow = []
        
        for j in range(0, len(constBuild.index)):
            G_Value = 0
            for i in range(1, len(constHeader)):
                gHeader = constHeader[i]
                elementName = "E_" + gHeader[2:]
                G_Value += dataRow[elementName] * constBuild.loc[j, gHeader]
            
            #extend the valueRow list with the new G_Value
            valueRow.extend([G_Value])   #The comparaison are in %, divide by 100 in advance
            
        #Append the complete list of G_Values to the modifiers table
        modifierValues.append(valueRow)
    
    colHeader = []
    colHeader.extend(constBuild["G_NAME"])
    G_Values = pd.DataFrame(modifierValues, columns = colHeader)
    
    #%% Process the class selection
    index = 0
    
    for i, dataRow in corrValues.iterrows():
        foundClass = False
        index = 0
        revCount = 0
        while(not foundClass):    
            
            testType = classSelection['TEST_TYPE'][index]
            testField = classSelection['TEST_FIELD'][index]
            testModifier = classSelection['MODIFIER'][index]
            testValue = classSelection['TEST_VALUE'][index]
            
            if (testModifier == 'DATA_TEST_S'): #String comparison
                if (corrValues[testField][i] == testValue):
                    result = classSelection['SUCCESS'][index]
                else:
                    result = classSelection['FAILURE'][index] 
                    
            else:
                #Build the Field and Modifier values
                if testModifier == 'CP_TEST':
                    valueField = BreakdownClassSelectionFile.FindCPM(corrValues["PART#"][i])
                    valueModifier = 1
                else:
                    percentTest = False
                    
                    if testField[:1] == 'G':
                        #testField is G_Value
                        valueField = G_Values[testField][i]
                    elif testField[:2] == 'E_':
                        #Compared values is in %
                        valueField = dataRow[testField]
                        percentTest = True
                    else:
                        #testFeld is with a direct value
                        valueField = corrValues[testField][i]
                    
                    
                    if testModifier[:1] == 'G':
                        #testModifier is G_Value
                        valueModifier = G_Values[testModifier][i]
                        if percentTest:
                            valueModifier *= 0.01   #Percent mode
                        
                    elif testModifier == 'DATA_TEST_F':
                        #Divider is 1
                        valueModifier = 1
                        
                    else:
                        #testModifier is in dataRow
                        valueModifier = dataRow[testModifier]
                
                #Do the test
                if testType == 'BiggerThan':
                    if valueModifier == 0:
                        result = classSelection['SUCCESS'][index]
                    else:
                        if (valueField / valueModifier) > float(testValue):
                            result = classSelection['SUCCESS'][index]
                        else:
                            result = classSelection['FAILURE'][index]
                        
                elif testType == 'BiggerOrEqual':
                    if valueModifier == 0:
                        result = classSelection['SUCCESS'][index]
                    else:
                        if (valueField / valueModifier) >= float(testValue):
                            result = classSelection['SUCCESS'][index]
                        else:
                            result = classSelection['FAILURE'][index]
                        
                elif testType == 'SmallerThan':
                    if valueModifier == 0:
                        result = classSelection['FAILURE'][index]
                    else:
                        if (valueField / valueModifier) < float(testValue):
                            result = classSelection['SUCCESS'][index]
                        else:
                            result = classSelection['FAILURE'][index]
                        
                elif testType == 'SmallerOrEqual':
                    if valueModifier == 0:
                        result = classSelection['FAILURE'][index]
                    else:
                        if (valueField / valueModifier) <= float(testValue):
                            result = classSelection['SUCCESS'][index]
                        else:
                            result = classSelection['FAILURE'][index]
                        
                elif testType == 'Equal':
                    if valueModifier == 0:
                        result = classSelection['FAILURE'][index]
                    else:
                        if (valueField / valueModifier) == float(testValue):
                            result = classSelection['SUCCESS'][index]
                        else:
                            result = classSelection['FAILURE'][index]
                    
            #Check if this is a final Result of a Goto
            if result[:1] == 'R':
                corrValues.loc[i, 'CLASS'] = result[2:]
                foundClass = True
            else:
                index = classSelection.index[classSelection['TEST_ID'] == int(result[2:])][0]
    
            revCount += 1
            
            if revCount > 30:
                sys.stdout.write("\nOver max while count for row of data {}. Last index {}  ".format(i, index))
                
    corrValues.to_csv('Data\Corrected_Values_Class.csv', index = False)

    
#%%Calculate and return the CPM Value
def FindCPM(PartNb):
    corrValues = pd.read_csv('Data\Corrected_Values.csv', low_memory = False)
    CPMFactor = pd.read_csv('Data\CPMFactor.csv', low_memory = False)
    
    data = corrValues[corrValues['PART#'] == PartNb].squeeze()
    CPMHeader = list(CPMFactor)
                                 
    CPMResult = []
    
    for i, CPMRow in CPMFactor.iterrows():
        if i == 0:
            #Skip the first row which is for density
            continue
        
        PjvSi = 0
        SivPj = 0
        
        totalInterest = data['E_NA'] + data['E_MG'] + data['E_AL'] + data['E_SI'] + data['E_CA'] + data['E_ZN'] + data['E_TI'] + data['E_K'] + data['E_FE'] + data['E_S']
        totalInterestStd = CPMRow['F_NA'] + CPMRow['F_MG'] + CPMRow['F_AL'] + CPMRow['F_SI'] + CPMRow['F_CA'] + CPMRow['F_ZN'] + CPMRow['F_TI'] + CPMRow['F_K'] + CPMRow['F_FE'] + CPMRow['F_S']
        
        for j in range(1, len(CPMHeader) - 1):
            Head = CPMHeader[j]
            HeadEle = "E_" + Head[2:]
            concStd = CPMRow[Head]
            concElem = data[HeadEle]
            
            if concStd == 0 or concElem == 0:
                MinRatio = 0
            else:
                if concStd > concElem:
                    MinRatio = concElem / concStd
                else:
                    MinRatio = concStd / concElem
            
            PjvSi = PjvSi + MinRatio * MinRatio * concStd / totalInterestStd
            SivPj = SivPj + MinRatio * MinRatio * concElem / totalInterest
        
        CPMResult.extend([PjvSi * SivPj * 100])    
     
    cpm = max(CPMResult)
    if cpm < 25:
        ind = 0
    else:
        ind = CPMResult.index(cpm) + 1

    return ind