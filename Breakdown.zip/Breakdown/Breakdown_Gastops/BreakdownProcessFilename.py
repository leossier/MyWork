
"""
Breakdown Gastops

Created on Thu Jun  7 13:45:33 2018

@author: Jeremy Barrette P928247
"""

print("\033[H\033[J") #clearing the console

#Importing Libraries
import sys, time
import pandas as pd
import math

import BreakdownClassSelectionFile

def BreakdownProcessFileName(FileName):
    ITREnd = FileName.find('_')
    ITR = FileName[:ITREnd]
    MCode = int(FileName[-6:-4])
    
    startSurf = FileName.find('NSURF')
    endSurf = (FileName[startSurf:]).find('_')
    surfaceValue = int(FileName[startSurf + 6:endSurf + startSurf])
    powerAdjust = endSurf - 7   #Based on number of digit of the Surface Value
    powerAdjust = math.pow(10, powerAdjust)     #Power of 10 to shift the surfaceValue
    surfaceValue = powerAdjust / surfaceValue
    
    #Import static .csv files
    sys.stdout.write("Loading... ")
    #To correct the elements concentrations
    corrTable = pd.read_csv('Data\CorrectionCode.csv', low_memory = False)
    #To correct the count, mass and volumes of the particles
    corrFactorsTable = pd.read_csv('Data\CorrectionFactor.csv', low_memory = False)

    #Import the raw data file
    rawData = pd.read_csv('Source files/' + FileName, low_memory = False)
    outData = rawData.copy(deep=True)
    outHeader = list(outData)
    outHeader[7] = "CorrCount"
    outHeader[8] = "Density"
    outHeader[12] = "Mass (ug)"
    outHeader[15] = "MassCorr (ug)"
    #Rename elements headers
    for i in range(38, len(outHeader)):
        outHeader[i] = "E_" + outHeader[i].upper()
    
    outData.columns = outHeader
    
    
    #%%Correcting the elements values
    sys.stdout.write("Correcting... ")
    
    corrCode = corrTable[corrTable['M-Code'] == MCode]
    LastVersion = max(corrCode['correction number'])
    
    corrIndex = corrCode.index[corrCode['correction number'] == LastVersion].tolist()[0]

    #Take the Elements value to a table
    colHeader = list(outData)
    for i in range(0, len(colHeader)):
        temp = colHeader[i]
        if temp[:2] == "E_":
            limit = i
            break
    
    for i, row in outData.iterrows():        
        #Correct the elements values
        elementsRaw = row[limit:]
        for ind in range(0, len(elementsRaw) - 1):
            elementHeader = colHeader[limit + ind]
            colName = "C_" + elementHeader[2:]
            outData.loc[i, elementHeader] = elementsRaw[ind] * corrCode[colName][corrIndex]
    
    #Save corrected values file                             
    outData.to_csv('Data\Corrected_Values.csv', index = False)    #TODO set the correct filename

    
    #%% Setting the classes and the mass/volume/correction values

    sys.stdout.write("Classifying... ")
    BreakdownClassSelectionFile.BuildClasses()
    
    #TODO Replace with gathering the data from the database
    densities = pd.read_csv('Data\CPMFactor.csv', low_memory = False)    #densities are on the first row (0)
    
    sys.stdout.write("Processing... ")
    
    #Add the columns for the new values
    postClassTable = pd.read_csv('Data\Corrected_Values_Class.csv', low_memory = False)
    
    #Find the correction Factor
    corrFactors = corrFactorsTable[corrFactorsTable['M-Code'] == MCode]
    LastVersion = max(corrFactors['correction number'])
    corrFactors = corrFactors[corrFactors['correction number'] == LastVersion]
    
    for ind, row in postClassTable.iterrows():
        
        partClass = int(int(row['CLASS'])/10000) #2 First digits of the class
        headCode = "C-" + str(partClass) + "0000"
    
        #Find particle size
        if row['DMAX'] < 1.5:
            partSize = 1
        elif row['DMAX'] < 2.5:
            partSize = 2
        elif row['DMAX'] < 5:
            partSize = 3
        elif row['DMAX'] < 30:
            partSize = 4
        elif row['DMAX'] < 100:
            partSize = 5
        else:
            partSize = 6
        postClassTable.loc[ind, 'CLASS'] += partSize 
        #With Particle size and HeadCode, find the correction factor
        corrFactor = corrFactors[headCode][corrFactors['Size_ID'] == partSize].tolist()[0]
        #Add the Corrected Count
        corrCount = corrFactor * surfaceValue
        postClassTable.loc[ind, 'CorrCount'] = corrCount
        #Calculate Density
        mainElement = row['FIRST_ELEM'].upper()
        density = densities['F_' + mainElement][0]
        postClassTable.loc[ind, 'Density'] = density
        #Add the mass
        volume = row['AREA'] * row['DMIN']
        mass = volume * density / 1000000
        postClassTable.loc[ind, 'Mass (ug)'] = mass
    
        #Add the corrected mass
        postClassTable.loc[ind, 'MassCorr (ug)'] = mass * corrCount
        
    postClassTable.to_csv('Result files/' + ITR + '.csv', index = False)
