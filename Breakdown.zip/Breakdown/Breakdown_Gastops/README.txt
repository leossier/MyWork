==BREAKDOWN==
BreakdownGastops.py, BreakdownProcessFilename.py, BreakdownClassSelectionFile.py
-Data Folder:
ClassSelection.csv, ConstantBuild.csv, CorrectionCode.csv, CorrectionFactor.csv, CPMFactor.csv

--Export Control Classification--
P-EARN: 9E991

--Usage--
All rawdata files to be processed must be in their non-corrected format (MXX) and placed in the "Sources files" folder. Their name must respect the perdetermined format. Once all the desiered file are placed, the tool can be run (TODO) and will generate the processed files in the "Result files" folder as csv file, named by their ITR.
