"""
Breakdown Gastops

Created on Thu Jul  24 11:05:33 2018

--Export Control Classification--
P-EAR: 9E991

@author: Jeremy Barrette P928247
"""


print("\033[H\033[J") #clearing the console

#Importing Libraries
import sys, time
import os

import BreakdownProcessFilename

dirPath = os.path.dirname(os.path.realpath(__file__))
dirSource = dirPath + "\Source files"
fileCount = len([name for name in os.listdir(dirSource) if os.path.isfile(os.path.join(dirSource, name))])

print("Breakdown process start [{}]".format(time.asctime(time.localtime(time.time()))))
print("Files to process: {}".format(fileCount))

startTime = time.time()
for file in os.listdir(dirSource):
    stepTime = time.time()
    filename = os.fsdecode(file)
    ITREnd = filename.find('_')
    ITR = filename[:ITREnd]
    sys.stdout.write("File: {} ".format(ITR))
    
    BreakdownProcessFilename.BreakdownProcessFileName(filename)
    
    sys.stdout.write(" Done: {:.2g} sec \n".format(time.time() - stepTime))

minutes, seconds = divmod(time.time() - startTime, 60)
print("Breakdown process completed. Total process time: {:0>2}:{:.2f} \n".format(int(minutes), int(seconds)))
