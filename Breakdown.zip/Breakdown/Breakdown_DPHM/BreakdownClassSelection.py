
"""
Breakdown Class Selection

Created on Mon Jun 11 15:24:11 2018

@author: Jeremy Barrette P928247
"""

import sys, time, datetime
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

import BreakdownClassSelection
import SQLServerOperations as SQL

def BuildClasses(ITR, db_connection):

    status, db_cursor = SQL.CreateDBCursor(db_connection)
    #To build the constants needed for the class selection
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_CONSTANT_BUILD]"
    constBuild = pd.read_sql(sqlCommand, db_connection)
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_CLASS_SELECTION]"
    classSelection = pd.read_sql(sqlCommand, db_connection)
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA]"
    corrValues = pd.read_sql(sqlCommand, db_connection)
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_RAW_DATA]"
    rawData = pd.read_sql(sqlCommand, db_connection)

    rawData = rawData[rawData['ITR_NO'] == ITR]
    
    #Build the G Values
    modifierValues = []
    constHeader = list(constBuild)
    for ind, dataRow in corrValues.iterrows():
        valueRow = []
        
        for j in range(0, len(constHeader)):    #For all constants to generate (columns)
            G_Value = 0
            for i in range(0, len(constBuild.index)):
                headerName = constBuild[constHeader[j]][i]
                if headerName == '0':
                    break
                else:
                    #Add the element to the G_Value
                    G_Value += dataRow[headerName]
            
            #extend the valueRow list with the new G_Value
            valueRow.extend([G_Value])   #The comparaison are in %, divide by 100 in advance
            
        #Append the complete list of G_Values to the modifiers table
        modifierValues.append(valueRow)
    
    colHeader = []
    colHeader.extend(constHeader)
    G_Values = pd.DataFrame(modifierValues, columns = colHeader)
    
    #%% Process the class selection
    index = 0
    
    for i, dataRow in corrValues.iterrows():
        partNo = dataRow['PART_NO']
        foundClass = False
        index = 0
        revCount = 0
        while(not foundClass):    
            
            testType = classSelection['Test_Type'][index]
            testField = classSelection['Test_Field'][index]
            testModifier = classSelection['Modifier'][index]
            testValue = classSelection['Test_Value'][index]
            
            if (testModifier == 'DATA_TEST_S'): #String comparison
                if (rawData[testField][i] == testValue):
                    result = classSelection['Success'][index]
                else:
                    result = classSelection['Failure'][index] 
                    
            else:
                #Build the Field and Modifier values
                if testModifier == 'CP_TEST':
                    valueField = BreakdownClassSelection.FindCPM(corrValues["PART_NO"][i])
                    valueModifier = 1
                else:
                    percentTest = False
                    
                    if testField[:1] == 'G':
                        #testField is G_Value
                        valueField = G_Values[testField][i]
                    elif testField[:2] == 'E_':
                        #testField is in dataRow
                        valueField = dataRow[testField]
                        percentTest = True
                    else:
                        #testFeld is in rawData
                        valueField = rawData[testField][i]
                    
                    
                    if testModifier[:1] == 'G':
                        #testModifier is G_Value
                        valueModifier = G_Values[testModifier][i]
                        if percentTest:
                            valueModifier *= 0.01   #Percent mode
                        
                    elif testModifier == 'DATA_TEST_F':
                        #Divider is 1
                        valueModifier = 1
                        
                    else:
                        #testModifier is in dataRow
                        valueModifier = dataRow[testModifier]
                
                #Do the test
                if testType == 'BiggerThan':
                    if valueModifier == 0:
                        result = classSelection['Success'][index]
                    else:
                        if (valueField / valueModifier) > float(testValue):
                            result = classSelection['Success'][index]
                        else:
                            result = classSelection['Failure'][index]
                        
                elif testType == 'BiggerOrEqual':
                    if valueModifier == 0:
                        result = classSelection['Success'][index]
                    else:
                        if (valueField / valueModifier) >= float(testValue):
                            result = classSelection['Success'][index]
                        else:
                            result = classSelection['Failure'][index]
                        
                elif testType == 'SmallerThan':
                    if valueModifier == 0:
                        result = classSelection['Failure'][index]
                    else:
                        if (valueField / valueModifier) < float(testValue):
                            result = classSelection['Success'][index]
                        else:
                            result = classSelection['Failure'][index]
                        
                elif testType == 'SmallerOrEqual':
                    if valueModifier == 0:
                        result = classSelection['Failure'][index]
                    else:
                        if (valueField / valueModifier) <= float(testValue):
                            result = classSelection['Success'][index]
                        else:
                            result = classSelection['Failure'][index]
                        
                elif testType == 'Equal':
                    if valueModifier == 0:
                        result = classSelection['Failure'][index]
                    else:
                        if (valueField / valueModifier) == float(testValue):
                            result = classSelection['Success'][index]
                        else:
                            result = classSelection['Failure'][index]
                    
            #Check if this is a final Result of a Goto
            if result[:1] == 'R':
                #TODO Replace with a write to DB=========================================================================
                    #-In the column 'CLASS'
                    #-For the row with ITR_NO == ITR and PART_NO = partNo
                corrValues.loc[i, 'CLASS'] = result[2:]
                foundClass = True
            else:
                index = classSelection.index[classSelection['Test_ID'] == int(result[2:])][0]
    
            revCount += 1
            if revCount > 40:
                #Safety for looped tests
                sys.stdout.write("\nOver max while count for row of data {}. Last index {}  ".format(i, index))

    
#%%Calculate and return the CPM Value
def FindCPM(PartNb, ITR, db_connection):
    status, db_cursor = SQL.CreateDBCursor(db_connection)
    
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA]"
    data = pd.read_sql(sqlCommand, db_connection)
    
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_CPM_FACTOR]"
    CPMFactor = pd.read_sql(sqlCommand, db_connection)
    
    data = data[data['ITR_NO'] == ITR]
    data = data[data['PART_NO'] == PartNb].squeeze()
    CPMHeader = list(CPMFactor)
                                 
    CPMResult = []
    
    for i, CPMRow in CPMFactor.iterrows():
        if i == 0:
            #Skip the first row which is for density
            continue
        
        PjvSi = 0
        SivPj = 0
        
        totalInterest = data['E_NA'] + data['E_MG'] + data['E_AL'] + data['E_SI'] + data['E_CA'] + data['E_ZN'] + data['E_TI'] + data['E_K'] + data['E_FE'] + data['E_S']
        totalInterestStd = CPMRow['F_NA'] + CPMRow['F_MG'] + CPMRow['F_AL'] + CPMRow['F_SI'] + CPMRow['F_CA'] + CPMRow['F_ZN'] + CPMRow['F_TI'] + CPMRow['F_K'] + CPMRow['F_FE'] + CPMRow['F_S']
         
        for j in (1, len(CPMHeader) - 1):
            Head = CPMHeader[j]
            HeadEle = "E_" + Head[2:]
            concStd = CPMRow[Head]
            concElem = data[HeadEle]
            
            if concStd == 0 or concElem == 0:
                MinRatio = 0
            else:
                if concStd > concElem:
                    MinRatio = concElem / concStd
                else:
                    MinRatio = concStd / concElem
            
            PjvSi = PjvSi + MinRatio * MinRatio * concStd / totalInterestStd
            SivPj = SivPj + MinRatio * MinRatio * concElem / totalInterest
        
        CPMResult.extend([PjvSi * SivPj * 100])    
     
    cpm = max(CPMResult)
    if cpm < 25:
        ind = 0
    else:
        ind = CPMResult.index(cpm) + 1

    return ind