# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 10:06:31 2018

@author: p928247
"""


print("\033[H\033[J") #clearing the console


#Importing Libraries
import pandas as pd
import SQLServerOperations as SQL
from sqlalchemy import create_engine

serverName = "WCALQD4U\BIDEV"
databaseName = "DPHM"

connection_str = SQL.DBConnectionString(serverName, databaseName)
status, db_connection = SQL.InitServerConnection(connection_str)
status, db_cursor = SQL.CreateDBCursor(db_connection)

engine = create_engine('mssql+pyodbc://' + serverName + '/' + databaseName)

if status != 0:
    print("Error in establishing connection")
else:
    
    if 1 == 0:   
        sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_RAW_DATA]"
        testTable = pd.read_sql(sqlCommand, db_connection)
        print(str(testTable))
    elif 1 == 0:
        table = pd.read_csv('Temp.csv', low_memory = False)
        collist = list(table)
        collist = str(collist).replace('[', '(')
        collist = collist.replace(']', ')')
        collist = collist.replace("'", "")
    
        vallist = table.loc[0]
        vallist = vallist.tolist()
        vallist = str(vallist).replace('[', '(')
        vallist = vallist.replace(']', ')')
        
        
        sql_command = 'INSERT INTO [DPHM].[dbo].[OilAT_PROCESSED_DATA] ' + collist + ' VALUES ' + vallist
        status = SQL.InsertIntoDB(db_connection, db_cursor, sql_command)
    elif 1 == 0:
        table = pd.read_csv('Temp.csv', low_memory = False)
        table.to_sql('OilAT_PROCESSED_DATA', con = engine, if_exists = 'append')
    else:
        sqlCommand = 'DELETE FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA] WHERE PART_NO = 0'
        status = SQL.InsertIntoDB(db_connection, db_cursor, sql_command)