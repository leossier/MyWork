
"""
Breakdown Process ITR

Created on Thu Jun  7 13:45:33 2018

@author: Jeremy Barrette P928247
"""

print("\033[H\033[J") #clearing the console

#Importing Libraries
import sys
import pandas as pd

import BreakdownClassSelection
import SQLServerOperations as SQL

def BreakdownProcessITR(ITR, serverName, databaseName):
    
    #Select the data for this ITR
    #TODO
    rawData = pd.read_csv('289208_01N_CF0577_TSN 00885_Engine PW308C_NSURF 0011535_M03.csv', low_memory = False)
 
    #Recover the M-Code and Surface Value
    #TODO
    MCode = 3
    SurfaceValue = 100 / 1.1535
    
    #TODO Import from database
    #To correct the elements concentrations
    corrTable = pd.read_csv('CorrectionCode.csv', low_memory = False)
    #To correct the count, mass and volumes of the particles
    corrFactorsTable = pd.read_csv('CorrectionFactor.csv', low_memory = False)
    
    #TODO If ITR already present in processedData, remove its data
    
    #%%Correcting the elements values
    
    sys.stdout.write('Correcting... ')

    corrCode = corrTable[corrTable['M-Code'] == MCode]
    LastVersion = max(corrCode['correction number'])
    
    corrIndex = corrCode.index[corrCode['correction number'] == LastVersion].tolist()[0]
    
    results = []
    #Take the Elements value to a table
    colHeader = list(rawData)
    for i in range(0, len(colHeader)):
        temp = colHeader[i]
        if temp[:2] == "E_":
            limit = i
            break
    
    for ind, row in rawData.iterrows():
        addRow = ['ITR#',      #FIXME complete based on final format
                   'FileName',
                   row['PART#'],
                   row['FIELD#'],
                   row['MAGFIELD#'],
                   row['DAVE'],
                   row['DMIN'],
                   row['DMAX'],
                   row['ASPECT'],
                   row['AREA'],
                   row['FIRST_ELEM']]
        
        #Correct the elements values
        elementsRaw = row[limit:]
        elementsCor = elementsRaw
        for ind in range(0, len(elementsRaw) - 1):
            colName = "C_" + (colHeader[limit + ind])[2:]
            corrector = corrCode[colName][corrIndex]
            elementsCor[ind] = elementsRaw[ind] * corrector
        
        addRow.extend(elementsCor)
        results.append(addRow)
        
    #Prepare the columns list
    R_Columns = ['ITR#', 'FILE_NAME', 'PART#', 'FIELD#', 'MAGFIELD#',
                 'D_AVERAGE', 'D_MIN', 'D_MAX', 'ASPECT', 'AREA', 'FIRST_ELEM']
    
    R_Columns.extend(colHeader[limit:])
    
    #Create DataBase from the results lists
    results_df = pd.DataFrame(results, columns = R_Columns)
                                
    results_df.to_csv('Corrected_Values.csv', index = False)    #TODO set the correct filename

    #%% Setting the classes and the mass/volume/correction values
    
    sys.stdout.write('Classifying the particles\n')
    
    #TODO Confirm the way to "select" the rows to process once on a server
    
    BreakdownClassSelection.BuildClasses(0) #TODO Replace with the correct ITR
    
    sys.stdout.write('Calculationg Mass and Volumes')
    
    #TODO Replace with gathering the data from the database
    densities = pd.read_csv('CPMFactor.csv', low_memory = False)    #densities are on the first row (0)
    
    #Add the columns for the new values
    postClassTable = pd.read_csv('Corrected_Values_Class.csv', low_memory = False)
    postClassTable['CORRECTED_COUNT'] = ""
    postClassTable['MASS'] = ""
    postClassTable['VOLUME'] = ""
    postClassTable['CORRECTED_MASS'] = ""
    
    #Find the correction Factor
    corrFactors = corrFactorsTable[corrFactorsTable['M-Code'] == MCode]
    LastVersion = max(corrFactors['correction number'])
    corrFactors = corrFactors[corrFactors['correction number'] == LastVersion]
    
    results = []
    
    for ind, row in postClassTable.iterrows():
        
        partClass = int(int(row['CLASS'])/10000) #2 First digits of the class
        HeadCode = "C-" + str(partClass) + "0000"
    
        #Find particle size
        if row['D_MAX'] < 1.5:
            partSize = 1
        elif row['D_MAX'] < 2.5:
            partSize = 2
        elif row['D_MAX'] < 5:
            partSize = 3
        elif row['D_MAX'] < 30:
            partSize = 4
        elif row['D_MAX'] < 100:
            partSize = 5
        else:
            partSize = 6
        postClassTable.loc[ind, 'CLASS'] += partSize 
        #With Particle size and HeadCode, find the correction factor
        corrFactor = corrFactors[HeadCode][corrFactors['Size_ID'] == partSize].tolist()[0]
        #Add the Corrected Count
        corrCount = corrFactor * SurfaceValue
        postClassTable.loc[ind, 'CORRECTED_COUNT'] = corrCount
        #Calculate Density
        mainElement = row['FIRST_ELEM']
        density = densities['E_' + mainElement][0]
        #Add volume
        volume = row['AREA'] * row['D_MIN']
        postClassTable.loc[ind, 'VOLUME'] = volume
        #Add the mass
        mass = volume * density / 1000000
        postClassTable.loc[ind, 'MASS'] = mass
    
        #Add the corrected mass
        postClassTable.loc[ind, 'CORRECTED_MASS'] = mass * corrCount
        
    
    postClassTable.to_csv('Corrected_Values_Masses.csv', index = False)
    
    #%% Finding and saving the particles fitting of interactions
    
    """
    
    sys.stdout.write('Classifying the interactions\n')
    
    #Open the reference files
    interactionMaterials = pd.read_csv('InteractionMaterials.csv', low_memory = False)
    interactionSelection= pd.read_csv('InteractionSelection.csv', low_memory = False)
    
    postInterTable = postClassTable.copy()
    
    length = len(postClassTable)
    #For all particles
    for ind, row in postClassTable.iterrows():
        
        #Process display
        if ind % 5 == 0:
            sys.stdout.write('{} / {} \n'.format(ind, length))
            limit += 1
        
        elementsList = []
        #For all interactions type
        for j, interaction in interactionSelection.iterrows():
            
            isThisInteraction = True
            #Recover information for the tests
            indexA = interactionMaterials.index[interactionMaterials['Material_ID'] == interaction['Material_A']].tolist()[0]
            indexB = interactionMaterials.index[interactionMaterials['Material_ID'] == interaction['Material_B']].tolist()[0]
            #indexA = interactionMaterials[interactionMaterials['Material_ID'] == interaction['Material_A']].index.tolist()[0]
            #indexB = interactionMaterials[interactionMaterials['Material_ID'] == interaction['Material_B']].index.tolist()[0]
            maxA = interaction['Max_A']
            minA = interaction['Min_A']
            
            #Find the normalized sum of the particle
            materialHeader = list(interactionMaterials)
            normSum = 0
            for k in range(2, len(materialHeader), 2):  #Step 2 because only want one of H_Element and L_Element
                if interactionMaterials.loc[indexA][k] > 0 or interactionMaterials.loc[indexB][k] > 0:
                    #Add the particle value of the element to the normalized sum
                    element = materialHeader[k]
                    element = temp[2:]
                    elementsList.extend(element)
                    normSum += row[element]
            
            #Compare the value with the H and L of the interaction
            for k in range(0, len(elementsList)):
                #Calculate the limits
                highValueMax = maxA * interactionMaterials.loc[indexA, "H_" + elementsList[k]]
                highValueMax += (100 - maxA) * interactionMaterials.loc[indexB, "H_" + elementsList[k]]
                highValueMax /= 100
                
                highValueMin = minA * interactionMaterials.loc[indexA, "H_" + elementsList[k]]
                highValueMin += (100 - minA) * interactionMaterials.loc[indexB, "H_" + elementsList[k]]
                highValueMin /= 100
                
                lowValueMax = maxA * interactionMaterials.loc[indexA, "L_" + elementsList[k]]
                lowValueMax += (100 - maxA) * interactionMaterials.loc[indexB, "L_" + elementsList[k]]
                lowValueMax /= 100
                
                lowValueMin = minA * interactionMaterials.loc[indexA, "L_" + elementsList[k]]
                lowValueMin += (100 - minA) * interactionMaterials.loc[indexB, "L_" + elementsList[k]]
                lowValueMin /= 100
    
                #Compare with the limits
                partValue = row['E_' + elementsList[k]]
                highValue = max(highValueMax, highValueMin)
                lowValue = min(lowValueMax, lowValueMin)
                
                if lowValue > partValue or partValue > highValue:
                    #The particle isn't from this interaction
                    isThisInteraction = False
                    break
                    
            #If it is fitting of this interaction, save the row as a new interaction
            if isThisInteraction:
                lastRow = len(postInterTable)
                postInterTable = postInterTable.append(row, ignore_index=True)
                temp = postInterTable.loc[lastRow - 1, "PART#"] + 1
                postInterTable.loc[lastRow, 'PART#'] = temp
                postInterTable.loc[lastRow, 'CLASS'] = 800000000 #TODO COMPLETE
                postInterTable.loc[lastRow, 'CLASS'] += (interaction['Interaction_ID'] * 100000 + interaction['Max_A'] * 1000 + interaction['Min_A'] * 10)
                postInterTable.loc[lastRow, 'CLASS'] += row['CLASS'] % 10   #Particle Size
    """      
    
    #%% Filling the "Like-SOAP" information
    
    
    sys.stdout.write('Building the Like-SOAP Class\n')
    
    elementSum = 0
    elementsList = []
    
    #TODO Replace postClassTable for the list of original particles (not the interactions)
    
    headers = list(postClassTable)
    for i in range(0, len(headers) - 1):
        header = headers[i]
        if header[:2] == "E_":
            colSum = postClassTable[header].sum()
            elementSum += colSum
            elementsList.extend([colSum])
        else:
            elementsList.extend([0])
           
            
    lastRow = len(postClassTable)
    resultRow = postClassTable.loc[lastRow - 1]
    for i in range(0, len(headers) - 1):
        header = headers[i]
        if header[:2] == "E_":
            resultRow[i] = elementsList[i] * 100 / elementSum
        else:
            resultRow[i] = ""
    
    
    postClassTable = postClassTable.append(resultRow, ignore_index = True)
    postClassTable.loc[lastRow, 'CLASS'] = 700000000