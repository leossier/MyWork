# -----------------------------------------------
# Imports
# -----------------------------------------------
import pyodbc


# -----------------------------------------------
# DBConnectionString
# -----------------------------------------------
def DBConnectionString(serverName, databaseName):

    connection_str = "Driver={SQL Server};Server="+serverName+";Database="+databaseName+";Trusted_Connection=yes;"

    return connection_str


# -----------------------------------------------
# InitServerConnection
# -----------------------------------------------
def InitServerConnection(connection_str):

    db_connection = None

    try:
        db_connection = pyodbc.connect(connection_str)

        status = 0

    except:
        status = 12001

    return status, db_connection


# -----------------------------------------------
# CreateDBCursor
# -----------------------------------------------
def CreateDBCursor(db_connection):

    db_cursor = None

    try:
        db_cursor = db_connection.cursor()

        status = 0

    except:
        status = 12002

    return status, db_cursor


# -----------------------------------------------
# InsertIntoDB
# -----------------------------------------------
def InsertIntoDB(db_connection, db_cursor, sql_command):

    try:
        #print(sql_command)
        db_cursor.execute(sql_command)

        db_connection.commit()

        status = 0

    except pyodbc.ProgrammingError:
        status = 12003

    return status


# -----------------------------------------------
# CloseServerConnection
# -----------------------------------------------
def CloseServerConnection(db_connection, db_cursor):

    try:
        db_cursor.close()
        del db_cursor
        db_connection.close()
        status = 0

    except pyodbc.DataError:
        status = 12004

    return status