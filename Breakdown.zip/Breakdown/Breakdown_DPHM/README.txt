===BREAKDOWN===
BreakdownDB.py, BreakdownProcessITR.py, BreakdownClassSelection.py

The main method in the BreakdownDB file has to be called after the "RawData" table has been updated with new values. This method will pass through the data and process the new ones and add the result in the "ProcessedData" table on the database.

The BreakdownProcessITR contains the necessary methods to process one sample based on its ITR and a database access. The BreakdownClassSelection file contains the methods to select and save the class of the particles of a sample. This method is independent from the ProcessITR since it might have to be changed in the futur, independant from the rest of the process. When that change has to be done, as long as the new file has the same file name, method name, parameters and output the class directly in the "CLASS" column of the database, the rest of the process shouldn't be affected.


*Rawdata update*

When importing the content of a rawdata files, the "FILE_NAME" field must be filled with the name of the file, including the ".csv". The "LAST_UPDATED" field must also be filled with the curent date. If data from an ITR already present in the database has to be updated, the old data has to be removed and replaced with the new one, with the "LAST_UPDATED" field set to the current date.