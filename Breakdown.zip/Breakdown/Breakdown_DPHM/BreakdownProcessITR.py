
"""
Breakdown Process ITR

Created on Thu Jun  7 13:45:33 2018

@author: Jeremy Barrette P928247
"""

print("\033[H\033[J") #clearing the console

#Importing Libraries
import sys
import pandas as pd
import math

import BreakdownClassSelection
import SQLServerOperations as SQL

def BreakdownProcessITR(ITR, db_connection):
    
    status, db_cursor = SQL.CreateDBCursor(db_connection)
    
    #Select the data for this ITR
    sqlCommand = "SELECT * FROM OilAT_RAW_DATA"
    rawData = pd.read_sql(sqlCommand, db_connection)
    rawData = rawData[rawData['ITR_NO'] == ITR]
    
    #Extract information from the file name
    FileName = rawData.loc[0, 'FILE_NAME']
    
    MCode = int(FileName[-6:-4])
    startSurf = FileName.find('NSURF')
    endSurf = (FileName[startSurf:]).find('_')
    surfaceValue = int(FileName[startSurf + 6:endSurf + startSurf])
    powerAdjust = endSurf - 7   #Based on number of digit of the Surface Value
    powerAdjust = math.pow(10, powerAdjust)     #Power of 10 to shift the surfaceValue
    surfaceValue = powerAdjust / surfaceValue
    
    #To correct the elements concentrations
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_M-CODE_CORRECTION]"
    corrTable = pd.read_sql(sqlCommand, db_connection)
    #To correct the count, mass and volumes of the particles
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_CORRECTION_FACTORS]"
    corrFactorsTable = pd.read_sql(sqlCommand, db_connection)
    
    #%%Correcting the elements values
    
    sys.stdout.write('Correcting... ')

    corrCode = corrTable[corrTable['M-Code'] == MCode]
    LastVersion = max(corrCode['correction number'])
    
    corrIndex = corrCode.index[corrCode['correction number'] == LastVersion].tolist()[0]
    
    results = []
    #Take the Elements value to a table
    colHeader = list(rawData)
    for i in range(0, len(colHeader)):
        temp = colHeader[i]
        if temp[:2] == "E_":
            limit = i
            break
 
    for ind, row in rawData.iterrows():
        addRow = [row['ITR_NO'],
                   row['FileName'],
                   row['PART_NO'],
                   row['FIELD_NO'],
                   row['MAGFIELD'],
                   row['D_AVG'],
                   row['D_MIN'],
                   row['D_MAX'],
                   row['ASPECT'],
                   row['AREA'],
                   row['COUNTS']]
        
        #Correct the elements values
        elementsRaw = row[limit:]
        elementsCor = elementsRaw
        for ind in range(0, len(elementsRaw) - 1):
            colName = "C_" + (colHeader[limit + ind])[2:]
            corrector = corrCode[colName][corrIndex]
            elementsCor[ind] = elementsRaw[ind] * corrector
        
        addRow.extend(elementsCor)
        #TODO Confirm that 0s can be set as default values for the colPostEl fields
        addRow.extend([0, 0, 0, 0, 0, 0, 0, 0])
        results.append(addRow)
    
    R_Columns = ['ITR_NO', 'FILE_NAME', 'PART_NO', 'FIELD_NO', 'MAGFIELD',
                 'D_AVG', 'D_MAX', 'D_MIN', 'ASPECT', 'AREA', 'COUNTS ']
    colPostEl = ['CORRECTED_COUNT', 'VOLUME', 'MASS', 'CORRECTED_MASS',
                 'CLASS', 'M-CODE', 'CORRECTION_NUMBER', 'LAST_UPDATED']
    R_Columns.extend(colHeader[limit:])
    R_Columns.extend(colPostEl)
    
    results_df = pd.DataFrame(results, columns = R_Columns)
                          
    #TODO Set the writing to the DB table as append
    results_df.to_sql('OilAT_PROCESSED_DATA', db_connection, if_exists = 'append')

    #%% Setting the classes and the mass/volume/correction values
    
    sys.stdout.write('Classifying the particles\n')
    
    BreakdownClassSelection.BuildClasses(ITR, db_connection)
    
    sys.stdout.write('Calculationg Mass and Volumes')
    
    sqlCommand = "SELECT * [DPHM].[dbo].[FROM OilAT_CPM_FACTORS]"
    densities = pd.read_sql(sqlCommand, db_connection)
    
    #Recover the data with the classes
    sqlCommand = "SELECT * [DPHM].[dbo].[FROM OilAT_PROCESSED_DATA]"
    postClassTable = pd.read_sql(sqlCommand, db_connection)
    
    #Find the correction Factor
    corrFactors = corrFactorsTable[corrFactorsTable['M-Code'] == MCode]
    LastVersion = max(corrFactors['correction number'])
    corrFactors = corrFactors[corrFactors['correction number'] == LastVersion]
    
    for ind, row in postClassTable.iterrows():
        partNo = row['PART_NO']
        partClass = int(int(row['CLASS'])/10000) #2 First digits of the class
        HeadCode = "C-" + str(partClass) + "0000"
    
        #Find particle size
        if row['D_MAX'] < 1.5:
            partSize = 1
        elif row['D_MAX'] < 2.5:
            partSize = 2
        elif row['D_MAX'] < 5:
            partSize = 3
        elif row['D_MAX'] < 30:
            partSize = 4
        elif row['D_MAX'] < 100:
            partSize = 5
        else:
            partSize = 6
            
        sqlBase = "UPDATE PROCESSED_DATA SET" 
        #TODO CHECK ALL OF THIS. Replace value in the DB, unsure about the variable value set
        resultClass = postClassTable.loc[ind, 'CLASS'] + partSize
        sqlCommand = sqlBase + "CLASS = " + str(resultClass) + "WHERE ITR_NO = " + str(ITR) + "AND PART_NO = " + str(partNo)

        #With Particle size and HeadCode, find the correction factor
        corrFactor = corrFactors[HeadCode][corrFactors['Size_ID'] == partSize].tolist()[0]
        #Add the Corrected Count
        corrCount = corrFactor * surfaceValue        
        sqlCommand = sqlBase + "CORRECTED_COUNT = " + str(corrCount) + "WHERE ITR_NO = " + str(ITR) + "AND PART_NO = " + str(partNo)      

        #Calculate Density
        mainElement = row['FIRST_ELEM']
        density = densities['E_' + mainElement][0]
        
        #Add volume
        volume = row['AREA'] * row['D_MIN']
        sqlCommand = sqlBase + "VOLUME = " + str(volume) + "WHERE ITR_NO = " + str(ITR) + "AND PART_NO = " + str(partNo)
        
        #Add the mass
        mass = volume * density / 1000000
        sqlCommand = sqlBase + "MASS = " + str(mass) + "WHERE ITR_NO = " + str(ITR) + "AND PART_NO = " + str(partNo)
    
        #Add the corrected mass
        corrMass = mass * corrCount
        sqlCommand = sqlBase + "CORRECTED_MASS = " + str(corrMass) + "WHERE ITR_NO = " + str(ITR) + "AND PART_NO = " + str(partNo)

    
    #%% Finding and saving the particles fitting of interactions
    
    #TODO ADD THE COMBINED ELEMENT IN MATERIALS
    """
    
    sys.stdout.write('Classifying the interactions\n')
    
    #Open the reference files
    interactionMaterials = pd.read_csv('InteractionMaterials.csv', low_memory = False)
    interactionSelection= pd.read_csv('InteractionSelection.csv', low_memory = False)
    
    postInterTable = postClassTable.copy()
    
    length = len(postClassTable)
    #For all particles
    for ind, row in postClassTable.iterrows():
        
        #Process display
        if ind % 5 == 0:
            sys.stdout.write('{} / {} \n'.format(ind, length))
            limit += 1
        
        elementsList = []
        #For all interactions type
        for j, interaction in interactionSelection.iterrows():
            
            isThisInteraction = True
            #Recover information for the tests
            indexA = interactionMaterials.index[interactionMaterials['Material_ID'] == interaction['Material_A']].tolist()[0]
            indexB = interactionMaterials.index[interactionMaterials['Material_ID'] == interaction['Material_B']].tolist()[0]
            #indexA = interactionMaterials[interactionMaterials['Material_ID'] == interaction['Material_A']].index.tolist()[0]
            #indexB = interactionMaterials[interactionMaterials['Material_ID'] == interaction['Material_B']].index.tolist()[0]
            maxA = interaction['Max_A']
            minA = interaction['Min_A']
            
            #Find the normalized sum of the particle
            materialHeader = list(interactionMaterials)
            normSum = 0
            for k in range(2, len(materialHeader), 2):  #Step 2 because only want one of H_Element and L_Element
                if interactionMaterials.loc[indexA][k] > 0 or interactionMaterials.loc[indexB][k] > 0:
                    #Add the particle value of the element to the normalized sum
                    element = materialHeader[k]
                    element = temp[2:]
                    elementsList.extend(element)
                    normSum += row[element]
            
            #Compare the value with the H and L of the interaction
            for k in range(0, len(elementsList)):
                #Calculate the limits
                highValueMax = maxA * interactionMaterials.loc[indexA, "H_" + elementsList[k]]
                highValueMax += (100 - maxA) * interactionMaterials.loc[indexB, "H_" + elementsList[k]]
                highValueMax /= 100
                
                highValueMin = minA * interactionMaterials.loc[indexA, "H_" + elementsList[k]]
                highValueMin += (100 - minA) * interactionMaterials.loc[indexB, "H_" + elementsList[k]]
                highValueMin /= 100
                
                lowValueMax = maxA * interactionMaterials.loc[indexA, "L_" + elementsList[k]]
                lowValueMax += (100 - maxA) * interactionMaterials.loc[indexB, "L_" + elementsList[k]]
                lowValueMax /= 100
                
                lowValueMin = minA * interactionMaterials.loc[indexA, "L_" + elementsList[k]]
                lowValueMin += (100 - minA) * interactionMaterials.loc[indexB, "L_" + elementsList[k]]
                lowValueMin /= 100
    
                #Compare with the limits
                partValue = row['E_' + elementsList[k]]
                highValue = max(highValueMax, highValueMin)
                lowValue = min(lowValueMax, lowValueMin)
                
                if lowValue > partValue or partValue > highValue:
                    #The particle isn't from this interaction
                    isThisInteraction = False
                    break
                    
            #If it is fitting of this interaction, save the row as a new interaction
            if isThisInteraction:
                lastRow = len(postInterTable)
                postInterTable = postInterTable.append(row, ignore_index=True)
                temp = postInterTable.loc[lastRow - 1, "PART#"] + 1
                postInterTable.loc[lastRow, 'PART#'] = temp
                postInterTable.loc[lastRow, 'CLASS'] = 800000000 #TODO COMPLETE
                postInterTable.loc[lastRow, 'CLASS'] += (interaction['Interaction_ID'] * 100000 + interaction['Max_A'] * 1000 + interaction['Min_A'] * 10)
                postInterTable.loc[lastRow, 'CLASS'] += row['CLASS'] % 10   #Particle Size
    """      
    
    #%% Filling the "Like-SOAP" information
    
    
    sys.stdout.write('Building the Like-SOAP Class\n')
    
    elementSum = 0
    elementsList = []
    
    #Take all data with a class under 700000000 to only have the 6XXXXXXXX representing the base particles
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA] WHERE ITR_NO = " + str(ITR) + "AND CLASS < 700000000"
    postInterTable = pd.read_sql(sqlCommand, db_connection)
    
    headers = list(postClassTable)
    for i in range(0, len(headers) - 1):
        header = headers[i]
        if header[:2] == "E_":
            colSum = postInterTable[header].sum()
            elementSum += colSum
            elementsList.extend([colSum])
        else:
            elementsList.extend([0])
           
    #TODO Keep ITR, increase Part No        
            
    lastRow = len(postInterTable)
    resultRow = postInterTable.loc[lastRow - 1]
    for i in range(0, len(headers) - 1):
        header = headers[i]
        if i > 1 and i < 5:
            #For Part_No, Field_No and Magfield: increment
            resultRow[i] = resultRow[i] + 1
        elif header[:2] == "E_":
            resultRow[i] = elementsList[i] * 100 / elementSum
        elif header == 'CLASS':
            resultRow[i] = 700000000
        elif i > 4:
            #All except ITR, FileName, Part_No, Field_No and Magfield
            resultRow[i] = ""
    
    
    postInterTable = postClassTable.append(resultRow, ignore_index = True)
    postInterTable.loc[lastRow, 'CLASS'] = 700000000