
"""
Breakdown DataBase

Created on Wed Aug  1 13:46:16 2018

@author: Jeremy Barrette P928247
"""

print("\033[H\033[J") #clearing the console

#Importing Libraries
import sys, time
import os
import pandas as pd

import BreakdownProcessITR as BD
import SQLServerOperations as SQL


def BreakdownRun(): #TODO Add serverName and databaseName in the funtion
    
    serverName = "WCALQD4U\BIDEV"
    databaseName = "DPHM"
    
    connection_str = SQL.DBConnectionString(serverName, databaseName)
    status, db_connection = SQL.InitServerConnection(connection_str)
    
    if status != 0:
        print("Error in establishing connection")

    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_CONSTANT_BUILD]"
    testTable = pd.read_sql(sqlCommand, db_connection)
    print(str(testTable))
    
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_RAW_DATA]"
    rawData = pd.read_sql(sqlCommand, db_connection)
    
    sqlCommand = "SELECT * FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA]"
    processedData = pd.read_sql(sqlCommand, db_connection)
    
    rawITR = rawData.ITR_NO.unique()
    processedITR = processedData.ITR_NO.unique()
    
    rawITR.sort()
    processedITR.sort()
    
    #Find the unprocessed ITR
    j = 0
    for i in range(0, len(rawITR)):
        if rawITR(i) == processedITR(j):    #ITR already processed
            j += 1
        elif rawITR(i) < processedITR(j):   #ITR not in raw data, unprobable
            i -= 1
            j += 1
        else:
            BD.BreakdownProcessITR(rawITR(i), db_connection)
    
    #TODO refresh processedData with the new samples added
            
    #Find reprocessed data
    for i in range(0, len(rawITR)):
        rawLastDate = rawData.loc[i, 'LAST_UPDATED']
        tempProcessedData = processedData[processedData['ITR_NO'] == rawITR[i]]
        
        #TODO compare with first element of  tempProcessedData to get processedDate
        processedDate = 0
        
        if rawLastDate > processedDate:
            sqlCommand = 'DELETE FROM [DPHM].[dbo].[OilAT_PROCESSED_DATA] WHERE ITR_NO = ' + rawITR[i]
            status = SQL.InsertIntoDB(db_connection, db_cursor, sql_command)
            BD.BreakdownProcessITR(rawITR(i), db_connection)
            
        
# -----------------------------------------------
# MAIN
# -----------------------------------------------
if __name__ == "__main__":
    BreakdownRun()
